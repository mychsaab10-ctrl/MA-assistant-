# MEERA AI  v2.5.0   (Developed by CH ADiL)

Android app (Kotlin + Jetpack Compose). Package: `com.meera.ai`.
Gemini chat, Gemini Live voice calls, phone automation, coding mode, memory, tools, animated avatar.

> Honest note: this project was written without a compiler. The first build can show small errors -
> paste the first `e:` line and it gets fixed. Nothing here is marked "tested".

## What is new in v2.4 (glass design, animated avatar, new icon)
- **Glassmorphism everywhere:** new `ui/Glass.kt` - deep gradient backdrop with soft colour light, frosted translucent panels (`GlassCard`, `glass()`),
  every `Button` / `OutlinedButton` in the app is now `PremiumButton` / `PremiumOutlinedButton` (gradient, glossy edge, glow, press effect).
  The old `GlowCard` name still works (it is glass now). Home buttons are in the same places as before.
- **Animated avatar (real video):** `avatar/AvatarVideoView.kt`, clips in `app/src/main/assets/avatar/` - used exactly as supplied (no re-encoding, same quality).
  Only the unused audio track of two clips was cut away (stream copy, video bits untouched) and the player is muted, so a clip can never take audio focus or play sound next to the Live call.
  | Clip | file |
  |---|---|
  | Home hologram / HUD | `home_hud.mp4` |
  | Blink + normal (listening) | `idle_normal.mp4` |
  | Speaking normal / happy / sad / excited / confused | `speak_normal / speak_happy / speak_sad / speak_excited / speak_confused.mp4` |
  | Thinking and speaking | `think_speak.mp4` |
  | Blink + sad (voice stopped / no internet) | `blink_sad.mp4` |
- **Morphflow:** two stacked players; the next clip (or the replay of the same clip) is prepared in the background, started ~0.4 s before the end and faded in over the old one,
  so a loop point or an expression change shows as a soft dissolve, never a jump. (It is a cross-dissolve of two real video frames - not AI frame interpolation.)
- **Home:** hologram scene full screen; when Meera reacts (chat mood) the matching clip morphs in, then back to the hologram. Tap the avatar to preview the next expression.
- **Call screen:** blinking normal clip while she listens; the speaking clip only while her voice is really playing (`CallState.Speaking`), chosen by the mood of her words
  (new mood `confused` added to `Mood`); no internet (`ConnectivityManager`) or call error -> `blink_sad`. Expression follows the words she says, ~0.4 s morph delay.
- **Icon:** your M/A image as adaptive icon (`drawable-nodpi/ic_launcher_fg_img.png` + blurred matching background), scaled so the title and "Assistant" text stay inside the launcher mask.
- The Home hologram clip (`home_hud.mp4`, 19 s) plays **with its own sound** (original file, nothing removed); the sound morphs with the picture and is switched off while a call is running (so it can never echo into the mic). All expression clips are muted.
- Build: `androidResources.noCompress += "mp4"`; APK is about 40 MB bigger because of the videos.
- **Not tested** (no compiler or device here). Small chat/eyes avatars (44 dp) still use the old light images.

## Also new in v2.5 (code written WITHOUT a compiler - build on GitHub Actions and send me the first error if any)
| Item | Status |
|---|---|
| 5.4 Detail mode | done: Settings "Reply length" Short/Auto/Detailed, `set_reply_style` tool, `ai/DetailMode.kt`, 8192 tokens + "Aage parho" button when cut by MAX_TOKENS, long spoken answers in calls |
| 5.5 Bluetooth call audio | done: `voice/AudioRoute.kt` (Auto: Bluetooth > wired > speaker, SCO on Android 8-11, communication device on 12+, live plug/unplug, Audio button with device menu, Bluetooth permission) |
| 5.7 End call by voice | done: `voice/EndCallCommands.kt` (own words only, negations ignored, goodbye then stop), `end_call` + `hangup_phone_call` tools (TelecomManager > call notification button > on-screen button) |
| 5.9 Reminders + nudges | done: `reminders/*` (exact alarms, boot/time-zone reschedule, missed list, notification buttons, tools, Reminders screen, wellness nudges default OFF) |
| 5.3 Live camera | done: session resumption + context compression + goAway reconnect (max 3), per-call snapshot fallback (setting stays "stream"), 768 px / <200 KB frames, fewer frames while she speaks or the picture is still, danger watch (HUD JSON `danger`, `[APP ALERT]`, red banner) |
| 5.1 Termux, 5.2 phone agent, 5.6 background + conversation memory, 5.8 self-fix, 5.10 task monitor | **not done yet** (separate rounds, so a build error can be found early) |

Limits: reminders on some phones (Xiaomi/Oppo...) need "battery optimisation off" and "autostart"; the danger watch is a helper, not a guarantee; screen-time nudge needs Usage access; hang-up of WhatsApp calls needs Notification access or Accessibility and is not confirmed by Android.

## What was new in v2.3 (owner ADIL, English app, maps, memory, phone control)
- **Language:** the whole app is English. Meera speaks only **Roman Urdu** and **English** (Settings -> language). Hindi/Hinglish options are gone;
  old settings are read as Roman Urdu. Fallback voice: ur-PK / en-IN / en-US (en-IN reads Roman Urdu best). Yes/no answers accept yes/no/haan/nahi (and Urdu script).
- **Owner:** `data/CoreFacts.kt` - "owner and developer is ADIL" is built into the code and the system prompt; it is not in the database, so it cannot be edited or deleted,
  and the prompt tells Meera to refuse anyone who claims otherwise. (Text chat cannot prove who is typing - no voice check yet.)
- **Maps / location:** tool `get_location` (GPS or network, honest accuracy, address via Geocoder), `phone_action` `navigate` (Google Maps turn-by-turn),
  `find_nearby`, `show_my_location`. Permission is asked the first time. Location is not stored.
- **Memory:** `data/AutoMemory.kt` extracts lasting facts from what you say (chat, fallback call, Live call) with one small Gemini request and saves new ones
  (Settings -> Memory -> Auto memory, default ON). Duplicates and sensitive text (passwords, OTPs, card/ID numbers) are skipped. The newest 80 memories + core facts go into every prompt.
  The normal chat (last 80 messages) is kept in private app storage. `remember` saves directly when you ask; `forget` deletes after a yes. Memory screen shows the locked core facts.
- **Phone control:** navigation, nearby search, flashlight, volume, media keys, phone status, email/share drafts, Play Store search, record video, gallery, many more settings pages
  (Wi-Fi/volume panels on Android 10+); with screen control on: swipe, type text, notifications, quick settings, lock screen, screenshot, power menu.
  Android does NOT allow: silent Wi-Fi/Bluetooth/airplane toggles, installing apps, bypassing the lock screen.
- **Not done yet (Version B):** recognizing Adil by voice and guest mode.
- **Not tested:** everything in 2.3 (no compiler or device was available); the accessibility config now has `canPerformGestures`, so after updating you may need to switch the
  Meera accessibility service off and on once.

## What was new in v2.2 - "Meera Aura" (voice border)
A premium glowing border around the screen edges: 3 glow layers + a bright line + travelling comets.
States: listening (cyan, slow breathing), thinking (violet, two comets), speaking (cyan-violet-pink flow, border width/glow pulse with the voice).
- Settings -> Meera Aura: Off / Sirf app me / Poore phone par, pulse strength 1-10, "also show while listening/thinking".
- "Poore phone par" draws the border over every app with a touch-through overlay window. It needs the Android permission
  "Display over other apps" (only the user can grant it) OR, on phones where that is switched off ("Feature not available"),
  Meera's Accessibility service, which may draw an overlay window (TYPE_ACCESSIBILITY_OVERLAY) without that permission.
  Without either, the in-app border is used.
  Android does not allow overlays on some secure screens (lock screen, some banking apps); some phones (Xiaomi, Oppo, Vivo...)
  need battery "unrestricted" for the call service so the overlay survives in the background.
- Voice level: Live call = real loudness (RMS) of the PCM audio being played (`AudioPlayer` -> `AuraController.feedPcm`).
  Android TextToSpeech (chat/fallback call) exposes no audio data, so there the pulse is a simulated speech-like envelope.
- Files: `aura/AuraController.kt`, `aura/AuraView.kt` (+ small hooks in MainActivity, Audio.kt, TtsEngine.kt).
- Not tested on a real device: overlay on different Android versions/OEMs, exact look of the glow, battery cost during long calls
  (the border redraws every frame while visible; turn on "only while speaking" in Settings to reduce it).

## What was new in v2.1 - "Meera Eyes" (camera)
**Open / close (only by your command - the camera never opens by itself):**
- Open: "Meera open your eyes", "aankhein kholo", "meera aankhein khol", "camera on".
- Close: "close your eyes", "aankhein band karo", "meera aankhein band kar", "camera off".
- Works in Chat (typed), the fallback voice call and the Live call. The app matches the words itself (local text match);
  Gemini is not trusted for this. In the Live call the tools `open_eyes` / `close_eyes` exist, but the app opens or closes
  the camera only if YOUR last sentence was a real command (same idea as `confirm_pending`).
- First time: Android asks for the CAMERA permission. Permissions screen shows Camera status + button.

**Eyes screen:** full-screen camera inside the app, red blinking "EYES ON", Close button, front/back switch, small avatar.
Nothing is recorded or saved (no gallery, no files; only in-memory frames). Closes on: close command, Close/Back button,
app going to background, auto-close timer (default 5 min), very hot phone, battery <= 8% (not charging).

**HUD:** every 2.5 s (Settings: 2-5 s) one 640 px JPEG (quality 70) goes to Gemini, which returns up to 8 objects
`{label, category, box_2d}` + a short scene summary. Corner brackets + label chip are drawn over the preview
(human red, animal cyan, plant green, vehicle orange, rest purple), boxes glide between scans and vanish 4 s after they
were last seen. If the previous request is still running the new frame is skipped. A person is only ever labelled
**HUMAN** (forced in code, not only in the prompt): no name, no face recognition, no age, no emotions.

**Questions:** with the eyes ON ask "ye kya hai?" / "isme kya hai?" / "ye kis cheez ka ped hai?" (type or dictate on the
Eyes screen, or speak in a fallback call). The current frame goes to Gemini with your question; Meera answers fully
(what it is, use, interesting facts, caution), in your language, by voice (TTS) and in a text card. Follow-up questions keep the context.
With only "eyes open" and no question, Meera stays silent and just shows the HUD (Settings -> "Continuous description", default OFF).

**Live call + camera:** the Live API accepts video as JPEG frames, max 1 per second (`realtimeInput.video`, per Google's docs).
- Mode **stream** (default): while the eyes are ON about 1 frame/second is sent to the Live session.
- Mode **snapshot**: no video is streamed; for each question the Live model calls the `look_camera` tool, the app takes one
  frame and the chat model answers. Switch in Settings. If the Live server closes the session right after the first
  frame (model without video support) the app switches to snapshot mode by itself and says so.
- What is NOT verified: whether YOUR key / your chosen Live model really accepts video. See `LiveSession.sendVideoFrame`.

**Settings:** scan interval 2-5 s, HUD on/off, default camera, auto-close minutes, continuous description, Live camera mode.

**Updating without uninstalling:** `app/debug.keystore` (fixed key, standard public "android" debug key) is committed and used in
`signingConfigs`. Termux and GitHub Actions builds are signed with the same key, so each new APK installs over the old one.
IMPORTANT: a Meera installed from an OLDER build (signed with some other debug key) must be uninstalled ONCE before 2.1 can
be installed (Android refuses a different signature). Uninstall deletes the app data (API key, memory): note them first.
Never delete or regenerate `app/debug.keystore`, and keep it in the repo (`.gitignore` already allows it).
This key is public: fine for your own phone, NOT for Play Store.

## What was new in v2.0
- **Name:** Yesmin -> **Meera** everywhere (app, package, prompts, scripts).
- **WhatsApp / SMS:** "WhatsApp par Ali ko hello bhejo" / "92300... ko sms karo ...".
  Meera asks "bhej doon? (haan / nahi)". After your "haan" the chat opens with the text typed in and,
  if screen control is ON, the accessibility service taps **Send** (it only taps inside WhatsApp / the SMS app).
  Otherwise you press Send yourself. Android decides whether the tap worked; Meera never claims delivery.
- **Contacts by name:** permission is asked only the first time you use a name. Contacts are searched on the phone only -
  names/numbers are never sent to Gemini.
- **Memory without popups:** Meera asks "yaad rakh loon?" in chat or by voice; you say/type "haan" and she saves it.
  Same for dialer, screen taps and message sending.
- **New Home (tech lab):** menu button (top-left, black/white) -> Memory, Phone automations, Tools & docs, Permissions,
  Settings, About, Owner details. Bottom: Chat (left), Call (center), Code `</>` (right) - icons only.
- **Avatar:** 8 WebP images (normal, happy, excited, sad, loving, thinking, talking, blink), ~50 KB each.
  Chat: Meera adds a hidden `[[MOOD: x]]` tag, the app hides it and changes the face (no tag = normal).
  Call: listening = normal, thinking = thinking, speaking = mouth opens/closes + mood guessed from her words.
  Tap the big avatar on Home to preview the next expression.
- **Lighter build:** ML Kit removed. OCR now uses Gemini vision (works for Hindi/Urdu too; the image you pick is sent to Gemini).

## Build in Termux (copy these one by one)
```
pkg update -y && pkg install -y unzip
termux-setup-storage
cd ~ && unzip -o ~/storage/downloads/MeeraAI.zip
cd MeeraAI && chmod +x gradlew *.sh
termux-wake-lock
sh setup-termux.sh        # one time: Java 17, Gradle 8.7 wrapper, Android SDK 34, aapt2
nohup sh build.sh > build.log 2>&1 &
tail -f build.log
```
The APK is copied to `Downloads/MeeraAI-debug.apk` (also `app/build/outputs/apk/debug/app-debug.apk`).
Install it, open **Settings** and paste your Gemini API key (aistudio.google.com), tap Test, then "Refresh list from Google".

### If Termux closes / "Killed" while building (4 GB phones)
1. Android Settings -> Apps -> Termux -> Battery -> **Unrestricted**. Lock Termux in recent apps.
2. Close all other apps. Developer options -> **Disable child process restrictions** (Android 12+).
3. Lower memory in `gradle.properties`: `-Xmx1536m` -> `-Xmx1100m` and `kotlin.daemon.jvmargs=-Xmx768m`.
4. Run again with the `nohup ... > build.log` line above; finished steps are cached, it continues.
5. Still failing? Build in the cloud (free): put this folder in a GitHub repo, open the **Actions** tab, run
   "Build Meera AI APK", download the artifact `MeeraAI-debug-apk`.

## Settings you may want
- **Chat model / Live model:** names change often. Use "Refresh list from Google". Default Live model: `gemini-3.1-flash-live-preview`.
- **Default country code** (WhatsApp/SMS): for numbers saved without +country code (auto-filled from your SIM, editable).
- **Screen control (Accessibility):** enable the service in Android Settings, then switch ON "Allow screen control"
  on the Phone Automation screen (it resets every time the app starts). Needed for auto-Send and screen reading.

## Permissions
Internet, Microphone (call/dictation), Camera (only for Meera Eyes, asked the first time you say "open your eyes"), Contacts (only when you use a name), Notifications, Set alarm.
Optional (you enable them in Android): Accessibility, Notification access.

## Honest limits
- WhatsApp may change its Send button; if the tap is not found Meera says so and you press Send.
- Live API model names / protocol change; if Live fails the call falls back to recognizer + Gemini + TTS automatically.
- Avatar images have a black background and are shown inside a round frame. Small differences between the
  images (headset, hair clips) are visible when the expression changes.
- No wake-word, no floating bubble, no screen capture.
- The API key is stored with Android Keystore encryption, but an APK can never hide a key completely from a rooted phone.
