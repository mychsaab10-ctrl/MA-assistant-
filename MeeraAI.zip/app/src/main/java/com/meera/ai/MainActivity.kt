@file:OptIn(ExperimentalMaterial3Api::class)

package com.meera.ai

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import android.view.ViewGroup
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.meera.ai.automation.QuickAccess
import com.meera.ai.ui.AboutScreen
import com.meera.ai.ui.AutomationScreen
import com.meera.ai.aura.AuraView
import com.meera.ai.ui.CallScreen
import com.meera.ai.ui.ChatScreen
import com.meera.ai.ui.EyesScreen
import com.meera.ai.ui.HomeScreen
import com.meera.ai.ui.MemoryScreen
import com.meera.ai.ui.MeeraTheme
import com.meera.ai.ui.glassBackdrop
import com.meera.ai.ui.OwnerScreen
import com.meera.ai.ui.PermissionsScreen
import com.meera.ai.ui.SettingsScreen
import com.meera.ai.ui.ToolsScreen
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val routeRequest = mutableStateOf<String?>(null)

    /** Asked the first time Meera needs a contact by NAME (never when a phone number is given). */
    private val contactsPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        Meera.toast(if (ok) "Contacts allowed. Please say your request again." else "Contacts not allowed. You can still send to a phone number.")
    }

    /** Asked the first time the user asks "where am I?" / "guide me to ..." (never on its own). */
    private val locationPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val ok = r.values.any { it }
        Meera.toast(if (ok) "Location allowed. Please ask again." else "Location not allowed. Allow it in the Permissions screen to use maps guidance.")
    }

    /** Asked the first time the user says "open your eyes" / "aankhein kholo" (never on its own). */
    private val cameraPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        Meera.eyes.onPermissionResult(ok)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        routeRequest.value = intent?.getStringExtra("route")
        intent?.getStringExtra("reminder")?.let { Meera.chat.note("⏰ $it") }
        Meera.requestContacts = { contactsPerm.launch(Manifest.permission.READ_CONTACTS) }
        Meera.requestCamera = { cameraPerm.launch(Manifest.permission.CAMERA) }
        Meera.requestLocation = {
            locationPerm.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        // Meera Aura (in-app mode): the border view sits on top of this window and lets every touch through
        auraJob = Meera.scope.launch { Meera.aura.inApp.collect { show -> setAuraVisible(show) } }
        if (Meera.settings.quickAccess) QuickAccess.show(this)
        setContent {
            val theme by Meera.settings.themeFlow.collectAsState()
            MeeraTheme(theme) {
                MeeraRoot(routeRequest.value) { routeRequest.value = null }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        routeRequest.value = intent.getStringExtra("route")
        intent.getStringExtra("reminder")?.let { Meera.chat.note("⏰ $it") }
    }

    private var auraView: AuraView? = null
    private var auraJob: Job? = null

    private fun setAuraVisible(show: Boolean) {
        val root = window.decorView as ViewGroup
        if (show) {
            if (auraView == null) {
                val v = AuraView(this)
                root.addView(v, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                auraView = v
            }
        } else {
            auraView?.let { root.removeView(it) }
            auraView = null
        }
    }

    /** The camera must never keep running while the app is not on screen. */
    override fun onStop() {
        Meera.eyes.close("Eyes closed: the app went to the background.")
        super.onStop()
    }

    override fun onDestroy() {
        auraJob?.cancel(); auraJob = null
        setAuraVisible(false)
        Meera.requestContacts = null
        Meera.requestCamera = null
        Meera.requestLocation = null
        super.onDestroy()
    }
}

private val backBarRoutes = listOf("chat", "call", "coding", "settings")

fun NavHostController.go(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MeeraRoot(requested: String?, consumed: () -> Unit) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    LaunchedEffect(requested) {
        if (requested != null) { nav.go(requested); consumed() }
    }
    BackHandler(drawer.isOpen) { scope.launch { drawer.close() } }
    val eyesOpen by Meera.eyes.isOpen.collectAsState()
    BackHandler(eyesOpen) { Meera.eyes.close() } // registered last = wins: Back closes the eyes first

    val items = listOf(
        Triple("memory", "Memory", Icons.Filled.Favorite),
        Triple("reminders", "Reminders", Icons.Filled.Notifications),
        Triple("automation", "Phone automations", Icons.Filled.Phone),
        Triple("tools", "Tools & docs", Icons.Filled.Build),
        Triple("permissions", "Permissions", Icons.Filled.Lock),
        Triple("settings", "Settings", Icons.Filled.Settings),
        Triple("about", "About", Icons.Filled.Info),
        Triple("owner", "Owner details", Icons.Filled.Person)
    )

    Box(Modifier.fillMaxSize().glassBackdrop()) {
        ModalNavigationDrawer(
            drawerState = drawer,
            gesturesEnabled = route == "home",
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surface) {
                    Text(
                        "MEERA AI", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 28.dp, vertical = 24.dp)
                    )
                    items.forEach { (r, label, icon) ->
                        NavigationDrawerItem(
                            label = { Text(label) },
                            icon = { Icon(icon, contentDescription = null) },
                            selected = route == r,
                            onClick = { scope.launch { drawer.close() }; nav.go(r) },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                        )
                    }
                }
            }
        ) {
            Scaffold(
                containerColor = androidx.compose.ui.graphics.Color.Transparent,
                topBar = {
                    if (route in backBarRoutes) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                        }
                    }
                }
            ) { pad ->
                NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                    composable("home") { HomeScreen(nav) { scope.launch { drawer.open() } } }
                    composable("chat") { ChatScreen(Meera.chat, "Meera Chat", coding = false) }
                    composable("call") { CallScreen() }
                    composable("coding") { ChatScreen(Meera.coding, "Coding Assistant", coding = true) }
                    composable("settings") { SettingsScreen() }
                    composable("automation") { AutomationScreen { nav.popBackStack() } }
                    composable("memory") { MemoryScreen { nav.popBackStack() } }
                    composable("reminders") { com.meera.ai.ui.RemindersScreen { nav.popBackStack() } }
                    composable("tools") { ToolsScreen { nav.popBackStack() } }
                    composable("permissions") { PermissionsScreen { nav.popBackStack() } }
                    composable("about") { AboutScreen { nav.popBackStack() } }
                    composable("owner") { OwnerScreen { nav.popBackStack() } }
                }
            }
        }
        // Meera Eyes: full-screen camera drawn over the whole app, only while the eyes are ON
        if (eyesOpen) EyesScreen()
    }
}
