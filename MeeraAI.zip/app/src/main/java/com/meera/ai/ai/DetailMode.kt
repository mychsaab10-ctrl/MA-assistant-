package com.meera.ai.ai

/**
 * "Reply length" (Settings: Short / Auto / Detailed). In Auto the user's own words decide for that one answer:
 * "detail se batao", "tafseel se", "poora batao", "explain in detail", Devanagari and Urdu script too.
 */
object DetailMode {
    const val SHORT = "short"
    const val NORMAL = "normal"
    const val DETAIL = "detail"

    private val detailWords = listOf(
        "detail", "tafseel", "tafsil", "tafseeli", "tafsheel", "poora batao", "pura batao", "poori baat", "puri baat", "poora bata",
        "pura bata", "mukammal", "lamba jawab", "lamba jawaab", "vistar", "vistaar", "explain fully", "elaborate", "thoroughly",
        "step by step", "in depth", "in-depth", "full explanation", "samjha ke batao", "samjha kar batao",
        "विस्तार", "तफ़सील", "तफसील", "पूरा बताओ", "पूरी बात", "पूरी तरह", "लंबा जवाब", "लम्बा जवाब", "डिटेल", "विस्तृत",
        "تفصیل", "تفصيل", "مکمل", "پوری بات", "پورا بتاؤ", "لمبا جواب", "ڈیٹیل", "وضاحت"
    )

    private val shortWords = listOf(
        "mukhtasar", "mukhtasir", "mukhtasar", "short mein", "short me", "short main", "chhota batao", "chota batao", "chhota jawab",
        "chota jawab", "briefly", "in short", "be brief", "short answer", "just tell me quickly", "sankshep",
        "संक्षेप", "छोटा बताओ", "छोटा जवाब", "مختصر", "چھوٹا بتاؤ", "چھوٹا جواب"
    )

    /** style = the saved setting (short | auto | detailed); text = the user's latest message. Returns SHORT | NORMAL | DETAIL. */
    fun mode(style: String, text: String): String {
        val t = text.lowercase()
        if (shortWords.any { t.contains(it) }) return SHORT
        return when (style) {
            "short" -> SHORT
            "detailed" -> DETAIL
            else -> if (detailWords.any { t.contains(it) }) DETAIL else NORMAL
        }
    }

    fun valid(style: String): Boolean = style == "short" || style == "auto" || style == "detailed"
}
