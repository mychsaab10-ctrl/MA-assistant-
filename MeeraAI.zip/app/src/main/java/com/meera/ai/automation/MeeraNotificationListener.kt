package com.meera.ai.automation

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow

data class NotifItem(val pkg: String, val title: String, val text: String, val time: Long)

/** Works only after the user grants Notification Access. Kept in memory only (never saved to disk). */
class MeeraNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        connected = true
        instance = this
        try {
            val now = activeNotifications?.mapNotNull { convert(it) }.orEmpty()
            recent.value = now.sortedByDescending { it.time }.take(30)
        } catch (e: Exception) { }
    }

    override fun onListenerDisconnected() {
        connected = false
        instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val item = sbn?.let { convert(it) } ?: return
        recent.value = (listOf(item) + recent.value).take(30)
    }

    private fun convert(sbn: StatusBarNotification): NotifItem? {
        if (sbn.packageName == packageName || sbn.isOngoing) return null
        val e = sbn.notification.extras ?: return null
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return null
        return NotifItem(sbn.packageName, title, text, sbn.postTime)
    }

    companion object {
        val recent = MutableStateFlow<List<NotifItem>>(emptyList())
        @Volatile var connected = false
        @Volatile private var instance: MeeraNotificationListener? = null

        private val hangWords = listOf("hang up", "hangup", "end call", "decline", "reject", "disconnect", "leave", "cut")

        /** Presses the hang-up / decline action of a running call notification (category "call"). false = none found. */
        fun hangUpCallNotification(): Boolean {
            val svc = instance ?: return false
            return try {
                for (sbn in svc.activeNotifications.orEmpty()) {
                    val n = sbn.notification ?: continue
                    if (n.category != Notification.CATEGORY_CALL) continue
                    for (a in n.actions.orEmpty()) {
                        val title = a.title?.toString()?.lowercase().orEmpty()
                        if (hangWords.any { title.contains(it) }) {
                            a.actionIntent.send()
                            return true
                        }
                    }
                }
                false
            } catch (e: Exception) {
                false
            }
        }
    }
}
