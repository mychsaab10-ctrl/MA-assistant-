package com.meera.ai.automation

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.ToolOut

/**
 * "Meri call kaat do": hangs up the USER'S phone / WhatsApp call (not Meera's own call).
 * Order: (a) TelecomManager.endCall (needs ANSWER_PHONE_CALLS, Android 9+), (b) the hang-up / decline button of the
 * call notification (needs Notification access), (c) tapping the on-screen End / Hang up button (needs Accessibility + screen control).
 * The result tells the truth: Android does not confirm (b) and (c), so the text says what was pressed, not "ended".
 */
object PhoneCallControl {

    @Suppress("DEPRECATION", "MissingPermission")
    fun hangUp(): ToolOut {
        val ctx: Context = Meera.app
        val tried = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= 28) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
                try {
                    val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                    if (tm.endCall()) return ToolOut("The phone call was ended (Android confirmed it).")
                    tried.add("Android reported no normal phone call to end")
                } catch (e: Exception) {
                    tried.add("phone call API failed")
                }
            } else tried.add("permission \"Hang up phone calls\" is off")
        } else tried.add("this Android version has no hang-up API")

        if (MeeraNotificationListener.hangUpCallNotification()) {
            return ToolOut(
                "I pressed the hang-up button in the call notification. Android does not confirm it, so tell the user " +
                    "it was pressed and ask them to check that the call has ended."
            )
        }
        tried.add(if (MeeraNotificationListener.connected) "no call notification with a hang-up button" else "Notification access is off")

        val svc = MeeraAccessibilityService.instance
        if (svc != null && Meera.accessGate.value) {
            if (svc.tapHangUp()) {
                return ToolOut(
                    "I tapped the on-screen End / Hang up button. Android does not confirm it, so tell the user " +
                        "it was tapped and ask them to check that the call has ended."
                )
            }
            tried.add("no End / Hang up button found on screen")
        } else tried.add("Accessibility / screen control is off")

        return ToolOut(
            "I could NOT end the call (" + tried.joinToString("; ") + "). Say this honestly to the user and tell them what to switch on " +
                "(Permissions screen: Hang up phone calls, Notification access, Accessibility)."
        )
    }
}
