package com.meera.ai.avatar

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.meera.ai.voice.CallState

/** Which clip matches what Meera is doing right now. */
object AvatarExpr {
    /** Mood of the words she is saying -> speaking clip. */
    fun speaking(mood: String): Clip = when (mood) {
        "happy", "loving" -> Clip.HAPPY
        "excited" -> Clip.EXCITED
        "sad" -> Clip.SAD
        "confused" -> Clip.CONFUSED
        "thinking" -> Clip.THINK
        else -> Clip.SPEAK
    }

    /**
     * Call screen: the mouth moves only while her voice is really playing (CallState.Speaking); otherwise she
     * stands there blinking. No internet or a broken call -> quiet and sad.
     */
    fun forCall(state: CallState, mood: String, online: Boolean): Clip = when {
        !online || state == CallState.Error -> Clip.BLINK_SAD
        state == CallState.Speaking -> speaking(mood)
        else -> Clip.IDLE
    }

    /** Home: the hologram scene while nothing is happening, her expression clip while she reacts. */
    fun forHome(mood: String): Clip = if (mood == "normal") Clip.HOME else speaking(mood)
}

/** Full-size animated avatar. Pauses with the screen and frees the players when it leaves the composition. */
@Composable
fun AvatarVideo(clip: Clip, modifier: Modifier = Modifier, focusX: Float = 0.5f, focusY: Float = 0.5f, sound: Boolean = true) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val holder = remember { arrayOfNulls<AvatarVideoView>(1) }
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            AvatarVideoView(ctx).also {
                it.focusX = focusX
                it.focusY = focusY
                it.soundOn = sound
                it.show(clip)
                holder[0] = it
            }
        },
        update = {
            it.focusX = focusX
            it.focusY = focusY
            it.soundOn = sound
            it.show(clip)
        }
    )
    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_PAUSE -> holder[0]?.pauseVideo()
                Lifecycle.Event.ON_RESUME -> holder[0]?.resumeVideo()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        onDispose {
            lifecycle.removeObserver(obs)
            holder[0]?.release()
            holder[0] = null
        }
    }
}

private fun hasInternet(ctx: Context): Boolean {
    val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return true
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/** true while the phone has a working network (updates live). */
@Composable
fun rememberOnline(): State<Boolean> {
    val ctx = LocalContext.current
    val s = remember { mutableStateOf(hasInternet(ctx)) }
    DisposableEffect(Unit) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { s.value = true }
            override fun onLost(network: Network) { s.value = hasInternet(ctx) }
        }
        try { cm?.registerDefaultNetworkCallback(cb) } catch (e: Exception) {}
        onDispose { try { cm?.unregisterNetworkCallback(cb) } catch (e: Exception) {} }
    }
    return s
}
