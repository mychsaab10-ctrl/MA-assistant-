package com.meera.ai.avatar

import android.content.Context
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.view.Surface
import android.view.TextureView
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout

/**
 * Meera's avatar clips (assets/avatar folder, mp4 files), used exactly as supplied (no re-encoding, same quality).
 * Only the Home hologram clip ([sound] = true) plays its own sound; every expression clip is muted.
 */
enum class Clip(val file: String, val sound: Boolean = false) {
    HOME("home_hud.mp4", sound = true),          // girl working on the hologram / HUD display
    IDLE("idle_normal.mp4"),       // blink + normal (standing, listening)
    SPEAK("speak_normal.mp4"),     // speaking, normal
    HAPPY("speak_happy.mp4"),      // speaking, happy
    SAD("speak_sad.mp4"),          // speaking, sad
    EXCITED("speak_excited.mp4"),  // speaking, excited
    THINK("think_speak.mp4"),      // thinking and speaking
    CONFUSED("speak_confused.mp4"),// speaking, confused
    BLINK_SAD("blink_sad.mp4")     // quiet, blinking, sad (voice stopped / no internet)
}

/**
 * Plays one clip at a time inside two stacked TextureViews. Every change of clip - and every replay of the
 * same clip - is a soft cross-fade ("morphflow"): the next player is prepared in the background, started a
 * moment before the current one ends and faded in over it, so the loop point is never visible.
 */
class AvatarVideoView(context: Context) : FrameLayout(context) {

    private class Slot(val tv: TextureView) {
        var surface: Surface? = null
        var mp: MediaPlayer? = null
        var clip: Clip? = null
    }

    private val a = Slot(TextureView(context))
    private val b = Slot(TextureView(context))
    private var frontIsA = true
    private val front: Slot get() = if (frontIsA) a else b
    private val back: Slot get() = if (frontIsA) b else a

    private val main = Handler(Looper.getMainLooper())
    private var wanted: Clip? = null
    private var paused = false
    private var released = false
    private var fading = false
    private var backReady = false
    private var backStarted = false
    private var backStartNow = false

    /** Crop alignment when the screen shape differs from the 9:16 video (0 = top/left, 1 = bottom/right). */
    var focusX: Float = 0.5f
        set(v) { field = v; applyTransform(a); applyTransform(b) }
    var focusY: Float = 0.5f
        set(v) { field = v; applyTransform(a); applyTransform(b) }

    /** Home hologram sound on/off (the app turns it off while a call is running so it can never echo into the mic). */
    var soundOn: Boolean = true
        set(v) { field = v; setVol(front, targetVol(front)); if (backStarted) setVol(back, targetVol(back)) }

    private val fadeMs = 420L

    private fun targetVol(s: Slot): Float = if (s.clip?.sound == true && soundOn) 1f else 0f

    private fun setVol(s: Slot, v: Float) {
        try { s.mp?.setVolume(v, v) } catch (e: Exception) { /* released */ }
    }

    private val forceFade = Runnable { if (backStarted && !fading) beginFade() }

    private val tick = object : Runnable {
        override fun run() {
            if (released) return
            try { loopCheck() } catch (e: Exception) { /* player was released meanwhile */ }
            main.postDelayed(this, 70L)
        }
    }

    init {
        setBackgroundColor(0xFF05070D.toInt())
        for (s in listOf(a, b)) {
            s.tv.alpha = 0.01f // not 0: some devices skip drawing (and never create the surface) at exactly 0
            addView(s.tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            s.tv.surfaceTextureListener = listenerFor(s)
        }
        main.postDelayed(tick, 100L)
    }

    private fun listenerFor(s: Slot) = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
            s.surface = Surface(st)
            applyTransform(s)
            reconcile()
        }
        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { applyTransform(s) }
        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { surfaceLost(s); return true }
        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
    }

    // ---- public API ----------------------------------------------------------------------------------

    fun show(c: Clip) {
        if (wanted == c) return
        wanted = c
        reconcile()
    }

    fun pauseVideo() {
        paused = true
        main.removeCallbacks(forceFade)
        try { front.mp?.pause() } catch (e: Exception) {}
        try { back.mp?.pause() } catch (e: Exception) {}
    }

    fun resumeVideo() {
        if (released) return
        paused = false
        try { front.mp?.start() } catch (e: Exception) {}
        if (backStarted) { try { back.mp?.start() } catch (e: Exception) {} }
        reconcile()
    }

    fun release() {
        if (released) return
        released = true
        main.removeCallbacksAndMessages(null)
        a.tv.animate().cancel(); b.tv.animate().cancel()
        for (s in listOf(a, b)) { releasePlayer(s); s.surface?.release(); s.surface = null }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        release()
    }

    // ---- internals -----------------------------------------------------------------------------------

    private fun releasePlayer(s: Slot) {
        val mp = s.mp
        s.mp = null
        s.clip = null
        if (mp != null) {
            try {
                mp.setOnPreparedListener(null); mp.setOnInfoListener(null); mp.setOnErrorListener(null)
                mp.release()
            } catch (e: Exception) {}
        }
    }

    private fun resetBack() {
        main.removeCallbacks(forceFade)
        releasePlayer(back)
        backReady = false
        backStarted = false
        backStartNow = false
    }

    private fun surfaceLost(s: Slot) {
        s.tv.animate().cancel()
        fading = false
        releasePlayer(s)
        resetBack()
        s.surface?.release()
        s.surface = null
    }

    /** Decide what to load next so that the clip shown matches [wanted]. */
    private fun reconcile() {
        if (released || paused || fading) return
        val w = wanted ?: return
        val f = front
        if (f.mp == null || f.clip != w) {
            val bk = back
            if (bk.mp == null || bk.clip != w) loadBack(w, true)
            else if (backReady && !backStarted) startBack()
            else if (!backStartNow) { backStartNow = true; if (backReady) startBack() }
        }
    }

    private fun loopCheck() {
        if (released || paused || fading) return
        val f = front
        val mp = f.mp ?: return
        val clip = f.clip ?: return
        if (wanted != clip) { reconcile(); return }
        val d = mp.duration
        if (d <= 0) return
        val rem = d - mp.currentPosition
        val bk = back
        if (bk.mp != null && bk.clip != clip) return // a different clip is already on its way
        if (bk.mp == null && rem <= 2000) loadBack(clip, false) // pre-load the replay while the end of the clip plays
        if (bk.clip == clip && backReady && !backStarted && rem <= fadeMs + 40) startBack()
    }

    private fun loadBack(c: Clip, startNow: Boolean) {
        resetBack()
        val s = back
        val surf = s.surface ?: return
        val mp = MediaPlayer()
        s.mp = mp
        s.clip = c
        backStartNow = startNow
        try {
            context.assets.openFd("avatar/${c.file}").use { afd ->
                mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            }
            mp.setSurface(surf)
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            mp.setVolume(0f, 0f) // starts silent; the cross-fade brings the Home clip's sound in (expression clips stay muted)
            mp.isLooping = false
            mp.setOnPreparedListener { p ->
                if (s.mp === p) {
                    backReady = true
                    if (backStartNow) startBack()
                }
            }
            mp.setOnInfoListener { p, what, _ ->
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START && s.mp === p && backStarted) beginFade()
                true
            }
            mp.setOnErrorListener { p, _, _ ->
                if (s.mp === p) resetBack()
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            resetBack()
        }
    }

    private fun startBack() {
        val mp = back.mp ?: return
        if (!backReady || backStarted || paused) return
        try {
            mp.start()
            backStarted = true
        } catch (e: Exception) {
            resetBack()
            return
        }
        main.postDelayed(forceFade, 1500L) // in case the "first frame" callback never comes
    }

    private fun beginFade() {
        if (fading || !backStarted || released) return
        main.removeCallbacks(forceFade)
        val inc = back
        val old = front
        fading = true
        applyTransform(inc)
        inc.tv.animate().cancel()
        inc.tv.alpha = 0.01f
        inc.tv.bringToFront()
        inc.tv.animate()
            .alpha(1f)
            .setDuration(fadeMs)
            .setInterpolator(AccelerateDecelerateInterpolator())
            .setUpdateListener { va ->
                val t = va.animatedFraction
                setVol(inc, t * targetVol(inc))          // sound morphs together with the picture
                setVol(old, (1f - t) * targetVol(old))
            }
            .withEndAction { finishFade(old, inc) }
            .start()
    }

    private fun finishFade(old: Slot, inc: Slot) {
        if (released || !fading) return
        old.tv.animate().cancel()
        old.tv.alpha = 0.01f
        releasePlayer(old)
        setVol(inc, targetVol(inc))
        frontIsA = inc === a
        fading = false
        backReady = false
        backStarted = false
        backStartNow = false
        reconcile()
    }

    private fun applyTransform(s: Slot) {
        val vw = s.tv.width.toFloat()
        val vh = s.tv.height.toFloat()
        if (vw <= 0f || vh <= 0f) return
        val fx = vw / VIDEO_W
        val fy = vh / VIDEO_H
        val sc = maxOf(fx, fy)                       // cover the whole view, keep the video's shape
        val m = Matrix()
        m.setScale(sc / fx, sc / fy, vw / 2f, vh / 2f)
        val exX = VIDEO_W * sc - vw
        val exY = VIDEO_H * sc - vh
        m.postTranslate(exX * (0.5f - focusX), exY * (0.5f - focusY))
        s.tv.setTransform(m)
    }

    private companion object {
        const val VIDEO_W = 720f
        const val VIDEO_H = 1280f
    }
}
