package com.meera.ai.reminders

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.meera.ai.MainActivity

/** Heads-up notification with "Ho gaya" / "10 min baad" / "Band karo" (wellness: "Ho gaya" / "Aaj chup"). Tapping opens Meera's chat with the reminder. */
object ReminderNotifier {
    const val CHANNEL = "reminders"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH)
            ch.description = "Meera's reminders and gentle nudges"
            nm.createNotificationChannel(ch)
        }
    }

    fun notificationsAllowed(ctx: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()

    fun show(ctx: Context, r: Reminder, missed: Boolean = false, test: Boolean = false) {
        ensureChannel(ctx)
        val text = when {
            test -> "Test: Meera ki yaad-dahani aisi dikhegi. ✅"
            missed -> "Ye choot gaya tha: ${r.text}"
            else -> r.text
        }
        val open = PendingIntent.getActivity(
            ctx, (r.id.toInt() * 8 + 5), Intent(ctx, MainActivity::class.java)
                .putExtra("route", "chat").putExtra("reminder", text)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(if (r.kind == "wellness") "Meera 💜" else "Meera ⏰")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
        if (!test) {
            b.addAction(0, "Ho gaya", ReminderScheduler.pending(ctx, r.id, ReminderScheduler.ACTION_DONE, extra = 1))
            b.addAction(0, "${ReminderScheduler.SNOOZE_MIN} min baad", ReminderScheduler.pending(ctx, r.id, ReminderScheduler.ACTION_SNOOZE, extra = 2))
            b.addAction(0, if (r.kind == "wellness") "Aaj chup" else "Band karo", ReminderScheduler.pending(ctx, r.id, ReminderScheduler.ACTION_STOP, extra = 3))
        }
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(notifId(r.id), b.build())
        } catch (e: SecurityException) {
            ReminderStore.log("notification blocked (permission)")
        }
    }

    fun notifId(id: Long) = 7000 + (id % 20000).toInt()

    fun dismiss(ctx: Context, id: Long) {
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(notifId(id))
    }
}
