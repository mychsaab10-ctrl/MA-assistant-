package com.meera.ai.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.meera.ai.Meera

/** Alarm fired, notification buttons, and re-scheduling after reboot / app update / time or time-zone change. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        ReminderStore.ensure(ctx)
        val id = intent.getLongExtra("id", -1L)
        when (intent.action) {
            ReminderScheduler.ACTION_FIRE -> fire(ctx, id, intent.getBooleanExtra("snooze", false))
            ReminderScheduler.ACTION_DONE -> { ReminderNotifier.dismiss(ctx, id); ReminderStore.log("done: #$id") }
            ReminderScheduler.ACTION_SNOOZE -> {
                ReminderNotifier.dismiss(ctx, id)
                ReminderStore.get(id)?.let { ReminderScheduler.scheduleSnooze(ctx, it); ReminderStore.log("snoozed ${ReminderScheduler.SNOOZE_MIN} min: ${it.text}") }
            }
            ReminderScheduler.ACTION_STOP -> {
                ReminderNotifier.dismiss(ctx, id)
                val r = ReminderStore.get(id)
                if (r != null) {
                    if (r.kind == "wellness") Wellness.muteToday(ctx)
                    else { ReminderScheduler.cancel(ctx, id); ReminderStore.save(r.copy(enabled = false, repeat = "none")) }
                    ReminderStore.log("stopped: ${r.text}")
                }
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> ReminderScheduler.rescheduleAll(ctx, reportMissed = true)
            Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> ReminderScheduler.rescheduleAll(ctx, reportMissed = false)
        }
    }

    private fun fire(ctx: Context, id: Long, snoozeFire: Boolean) {
        val r = ReminderStore.get(id) ?: return
        if (!snoozeFire && !r.enabled) return
        val now = System.currentTimeMillis()
        var shown = r
        var show = true
        if (r.kind == "wellness") {
            val t = Wellness.textIfAllowed(ctx, r)
            if (t == null) show = false else shown = r.copy(text = t)
        }
        if (show) {
            ReminderNotifier.show(ctx, shown)
            ReminderStore.log("fired: ${shown.text}")
            // a running Live call hears about it too (no phone TTS: it would echo into the mic)
            try { Meera.call.sendAppAlert("[APP ALERT] Reminder just fired: ${shown.text}. Tell the user in one short sentence.") } catch (e: Throwable) { }
        }
        if (snoozeFire) return // a snooze does not move the real schedule
        val n = ReminderScheduler.next(r, now)
        val updated = if (n != null) r.copy(triggerAt = n, lastFired = now, snoozedUntil = 0L) else r.copy(enabled = false, lastFired = now)
        ReminderStore.save(updated)
        ReminderScheduler.schedule(ctx, updated)
    }
}
