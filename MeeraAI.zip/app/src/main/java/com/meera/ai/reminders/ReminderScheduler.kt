package com.meera.ai.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** AlarmManager side: one exact alarm per reminder (setExactAndAllowWhileIdle) with a gentler fallback when "exact alarms" are not allowed. */
object ReminderScheduler {
    const val ACTION_FIRE = "com.meera.ai.REMINDER_FIRE"
    const val ACTION_DONE = "com.meera.ai.REMINDER_DONE"
    const val ACTION_SNOOZE = "com.meera.ai.REMINDER_SNOOZE"
    const val ACTION_STOP = "com.meera.ai.REMINDER_STOP"
    const val SNOOZE_MIN = 10

    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canExact(ctx: Context): Boolean = Build.VERSION.SDK_INT < 31 || am(ctx).canScheduleExactAlarms()

    fun pending(ctx: Context, id: Long, action: String, snooze: Boolean = false, extra: Int = 0): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).setAction(action).putExtra("id", id).putExtra("snooze", snooze)
        val code = (id.toInt() * 8 + extra) xor (if (snooze) 0x40000000 else 0)
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun set(ctx: Context, at: Long, pi: PendingIntent) {
        val a = am(ctx)
        try {
            if (canExact(ctx)) a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) // a little late, but it still comes
        } catch (e: SecurityException) {
            a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun schedule(ctx: Context, r: Reminder) {
        cancel(ctx, r.id)
        if (!r.enabled) return
        set(ctx, maxOf(r.triggerAt, System.currentTimeMillis() + 1500L), pending(ctx, r.id, ACTION_FIRE))
    }

    fun scheduleSnooze(ctx: Context, r: Reminder, minutes: Int = SNOOZE_MIN) {
        set(ctx, System.currentTimeMillis() + minutes * 60_000L, pending(ctx, r.id, ACTION_FIRE, snooze = true))
    }

    fun cancel(ctx: Context, id: Long) {
        val a = am(ctx)
        a.cancel(pending(ctx, id, ACTION_FIRE))
        a.cancel(pending(ctx, id, ACTION_FIRE, snooze = true))
    }

    /** Next time after [from] for a repeating reminder (null = does not repeat). DST-safe (Calendar). */
    fun next(r: Reminder, from: Long): Long? {
        if (r.repeat == "none") return null
        if (r.repeat.startsWith("every_")) {
            val m = r.repeat.removePrefix("every_").removeSuffix("_min").toLongOrNull() ?: return null
            var t = r.triggerAt
            val step = maxOf(m, 1L) * 60_000L
            while (t <= from) t += step
            return t
        }
        val c = Calendar.getInstance().apply { timeInMillis = r.triggerAt }
        var guard = 0
        do {
            when (r.repeat) {
                "weekly" -> c.add(Calendar.DAY_OF_YEAR, 7)
                else -> c.add(Calendar.DAY_OF_YEAR, 1)
            }
            guard++
        } while ((c.timeInMillis <= from || weekendSkip(r, c)) && guard < 800)
        return c.timeInMillis
    }

    private fun weekendSkip(r: Reminder, c: Calendar): Boolean {
        if (r.repeat != "weekdays") return false
        val d = c.get(Calendar.DAY_OF_WEEK)
        return d == Calendar.SATURDAY || d == Calendar.SUNDAY
    }

    /**
     * After boot / app update / time or time-zone change: schedule everything again. Reminders whose time passed while the
     * phone was off are shown once as "missed" (normal reminders only) and then moved to their next time.
     */
    fun rescheduleAll(ctx: Context, reportMissed: Boolean) {
        ReminderStore.ensure(ctx)
        val now = System.currentTimeMillis()
        for (r0 in ReminderStore.all()) {
            var r = r0
            if (!r.enabled) continue
            if (r.triggerAt < now - 60_000L) {
                if (reportMissed && r.kind == "reminder") {
                    ReminderNotifier.show(ctx, r, missed = true)
                    ReminderStore.log("missed while off: ${r.text}")
                }
                val n = next(r, now)
                r = if (n != null) r.copy(triggerAt = n) else r.copy(enabled = false)
                ReminderStore.save(r)
            }
            schedule(ctx, r)
        }
    }
}
