package com.meera.ai.reminders

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * kind: reminder | wellness.  repeat: none | daily | weekdays | weekly | every_N_min.
 * Own small database (reminders.db) so the memory database and its data are never touched.
 */
data class Reminder(
    val id: Long, val text: String, val kind: String, val triggerAt: Long, val repeat: String,
    val enabled: Boolean, val snoozedUntil: Long, val createdAt: Long, val lastFired: Long
)

object ReminderStore {
    private class Helper(c: Context) : SQLiteOpenHelper(c, "reminders.db", null, 1) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, kind TEXT NOT NULL, triggerAt INTEGER NOT NULL, " +
                    "repeat TEXT NOT NULL, enabled INTEGER NOT NULL, snoozedUntil INTEGER NOT NULL, createdAt INTEGER NOT NULL, lastFired INTEGER NOT NULL)"
            )
            db.execSQL("CREATE TABLE rlog(ts INTEGER NOT NULL, line TEXT NOT NULL)")
        }
        override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    }

    private var helper: Helper? = null
    val items = MutableStateFlow<List<Reminder>>(emptyList())

    @Synchronized
    fun ensure(ctx: Context) {
        if (helper == null) helper = Helper(ctx.applicationContext)
        refresh()
    }

    private fun db(): SQLiteDatabase = helper!!.writableDatabase

    fun refresh() { if (helper != null) items.value = all() }

    fun all(): List<Reminder> {
        val out = ArrayList<Reminder>()
        db().rawQuery("SELECT id,text,kind,triggerAt,repeat,enabled,snoozedUntil,createdAt,lastFired FROM reminders ORDER BY triggerAt", null).use { c ->
            while (c.moveToNext()) {
                out.add(Reminder(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getString(4), c.getInt(5) == 1, c.getLong(6), c.getLong(7), c.getLong(8)))
            }
        }
        return out
    }

    fun get(id: Long): Reminder? = all().firstOrNull { it.id == id }

    fun add(text: String, kind: String, triggerAt: Long, repeat: String): Reminder {
        val now = System.currentTimeMillis()
        val v = ContentValues().apply {
            put("text", text); put("kind", kind); put("triggerAt", triggerAt); put("repeat", repeat)
            put("enabled", 1); put("snoozedUntil", 0L); put("createdAt", now); put("lastFired", 0L)
        }
        val id = db().insert("reminders", null, v)
        refresh()
        return Reminder(id, text, kind, triggerAt, repeat, true, 0L, now, 0L)
    }

    fun save(r: Reminder) {
        val v = ContentValues().apply {
            put("text", r.text); put("kind", r.kind); put("triggerAt", r.triggerAt); put("repeat", r.repeat)
            put("enabled", if (r.enabled) 1 else 0); put("snoozedUntil", r.snoozedUntil); put("lastFired", r.lastFired)
        }
        db().update("reminders", v, "id=?", arrayOf(r.id.toString()))
        refresh()
    }

    fun delete(id: Long) {
        db().delete("reminders", "id=?", arrayOf(id.toString()))
        refresh()
    }

    fun deleteKind(kind: String) {
        db().delete("reminders", "kind=?", arrayOf(kind))
        refresh()
    }

    // ---- small log for Diagnostics: fired / missed / skipped reminders ----
    fun log(line: String) {
        try {
            val v = ContentValues().apply { put("ts", System.currentTimeMillis()); put("line", line.take(200)) }
            db().insert("rlog", null, v)
            db().execSQL("DELETE FROM rlog WHERE ts NOT IN (SELECT ts FROM rlog ORDER BY ts DESC LIMIT 60)")
        } catch (e: Exception) { }
    }

    fun logLines(): List<Pair<Long, String>> {
        val out = ArrayList<Pair<Long, String>>()
        try {
            db().rawQuery("SELECT ts,line FROM rlog ORDER BY ts DESC LIMIT 30", null).use { c ->
                while (c.moveToNext()) out.add(c.getLong(0) to c.getString(1))
            }
        } catch (e: Exception) { }
        return out
    }

    fun clearLog() { try { db().execSQL("DELETE FROM rlog") } catch (e: Exception) { } }
}
