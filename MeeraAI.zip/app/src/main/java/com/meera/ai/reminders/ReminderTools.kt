package com.meera.ai.reminders

import com.meera.ai.Meera
import com.meera.ai.ToolOut
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Gemini tools: set_reminder, list_reminders, cancel_reminder, update_reminder, get_time. A tool only says "set" when it really is stored AND scheduled. */
object ReminderTools {
    private val show = DateTimeFormatter.ofPattern("EEE d MMM, HH:mm", Locale.ENGLISH)
    private val repeats = setOf("none", "daily", "weekdays", "weekly")

    private fun fmt(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(show)

    /** "2026-11-11T08:00" (local) or with offset / Z. null = not understood. */
    private fun parseAt(s: String): Long? {
        val t = s.trim().replace(' ', 'T')
        if (t.isEmpty()) return null
        try { return OffsetDateTime.parse(t).toInstant().toEpochMilli() } catch (e: Exception) { }
        try { return ZonedDateTime.parse(t).toInstant().toEpochMilli() } catch (e: Exception) { }
        try { return LocalDateTime.parse(t).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() } catch (e: Exception) { }
        return null
    }

    private fun normRepeat(s: String): String? {
        val r = s.trim().lowercase().ifEmpty { "none" }
        if (r in repeats) return r
        val m = Regex("every_(\\d{1,4})_min").matchEntire(r) ?: return null
        return if (m.groupValues[1].toInt() >= 5) r else null
    }

    private fun warnings(): String {
        val ctx = Meera.app
        val w = ArrayList<String>()
        if (!ReminderNotifier.notificationsAllowed(ctx)) w.add("notifications are OFF so no alert will show (tell the user to allow notifications in the Permissions screen)")
        if (!ReminderScheduler.canExact(ctx)) w.add("exact alarms are not allowed so it may come a little late (Reminders screen has the switch)")
        return if (w.isEmpty()) "" else " Warning: " + w.joinToString("; ") + "."
    }

    fun run(name: String, args: JSONObject): ToolOut? {
        val ctx = Meera.app
        ReminderStore.ensure(ctx)
        return when (name) {
            "get_time" -> {
                val z = ZonedDateTime.now()
                ToolOut("Now: " + z.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH)) + " (timezone ${z.zone.id}).")
            }
            "set_reminder" -> setReminder(args)
            "list_reminders" -> {
                val l = ReminderStore.all().filter { it.kind == "reminder" && it.enabled }
                if (l.isEmpty()) ToolOut("No active reminders.")
                else ToolOut(l.joinToString("\n") { "#${it.id}: ${it.text} - ${fmt(it.triggerAt)}" + if (it.repeat != "none") " (repeat ${it.repeat})" else "" })
            }
            "cancel_reminder" -> {
                val id = args.optLong("id", -1L)
                val q = args.optString("text").trim().lowercase()
                val hits = ReminderStore.all().filter { it.kind == "reminder" && (it.id == id || (q.isNotEmpty() && it.text.lowercase().contains(q))) }
                when {
                    hits.isEmpty() -> ToolOut("No reminder matched. Use list_reminders and ask the user which one.")
                    hits.size > 1 && id < 0 -> ToolOut("More than one matches: " + hits.joinToString("; ") { "#${it.id} ${it.text}" } + ". Ask the user which one.")
                    else -> { val r = hits.first(); ReminderScheduler.cancel(ctx, r.id); ReminderStore.delete(r.id); ToolOut("Cancelled: ${r.text}.") }
                }
            }
            "update_reminder" -> update(args)
            else -> null
        }
    }

    private fun setReminder(a: JSONObject): ToolOut {
        val ctx = Meera.app
        val text = a.optString("text").trim()
        if (text.isEmpty()) return ToolOut("No reminder text given. Ask the user what to remind.")
        val now = System.currentTimeMillis()
        val at: Long = when {
            a.has("in_minutes") && a.optDouble("in_minutes", 0.0) > 0 -> now + (a.optDouble("in_minutes") * 60_000.0).toLong()
            a.optString("at").isNotBlank() -> parseAt(a.optString("at"))
                ?: return ToolOut("I could not read that time. Ask the user for a clear time (for example 'kal subah 8 baje').")
            else -> return ToolOut("No time given. Ask the user when (for example '5 baje' - morning or evening?).")
        }
        if (at <= now + 5_000L) return ToolOut("That time has already passed. Ask the user for a time in the future.")
        val rep = normRepeat(a.optString("repeat")) ?: return ToolOut("Unknown repeat. Use none, daily, weekdays, weekly or every_N_min (N >= 5).")
        val r = ReminderStore.add(text, "reminder", at, rep)
        ReminderScheduler.schedule(ctx, r)
        return ToolOut("Reminder set (#${r.id}): \"$text\" at ${fmt(at)}" + (if (rep != "none") ", repeat $rep" else "") + "." + warnings() + " Say the exact time to the user.")
    }

    private fun update(a: JSONObject): ToolOut {
        val ctx = Meera.app
        val id = a.optLong("id", -1L)
        val r = ReminderStore.get(id) ?: return ToolOut("No reminder with that id. Use list_reminders.")
        var n = r
        if (a.optString("text").isNotBlank()) n = n.copy(text = a.optString("text").trim())
        val now = System.currentTimeMillis()
        if (a.has("in_minutes") && a.optDouble("in_minutes", 0.0) > 0) n = n.copy(triggerAt = now + (a.optDouble("in_minutes") * 60_000.0).toLong(), enabled = true)
        else if (a.optString("at").isNotBlank()) {
            val t = parseAt(a.optString("at")) ?: return ToolOut("I could not read that time. Ask the user.")
            if (t <= now) return ToolOut("That time has already passed.")
            n = n.copy(triggerAt = t, enabled = true)
        }
        if (a.has("repeat")) n = n.copy(repeat = normRepeat(a.optString("repeat")) ?: return ToolOut("Unknown repeat."))
        if (a.has("enabled")) n = n.copy(enabled = a.optBoolean("enabled", true))
        ReminderStore.save(n)
        ReminderScheduler.schedule(ctx, n)
        return ToolOut("Updated #${n.id}: \"${n.text}\" at ${fmt(n.triggerAt)}" + (if (n.repeat != "none") ", repeat ${n.repeat}" else "") + (if (!n.enabled) " (off)" else "") + "." + warnings())
    }
}
