package com.meera.ai.reminders

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.PowerManager
import android.os.Process
import java.util.Calendar

/**
 * Meera's gentle nudges (all OFF by default). They are ordinary rows of kind "wellness" in the reminder store, created from the
 * switches on the Reminders screen. Limits are checked when a nudge is due: quiet hours, max 6 a day, one kind per 2 hours,
 * and "Aaj chup" silences all nudges for the rest of the day. The tone is friendly - no advice, no medical talk.
 */
object Wellness {
    private const val PREFS = "meera_wellness"
    val kinds = listOf("meals", "water", "eyes", "walk", "sleep", "screen")
    val labels = mapOf(
        "meals" to "Khana (naashta / dopahar / raat)", "water" to "Paani (har 2 ghante, din mein)",
        "eyes" to "Aankhon ka break (20-20-20, jab phone chal raha ho)", "walk" to "Uthke chalo (har 90 min, jab phone chal raha ho)",
        "sleep" to "Neend ka waqt (raat 10:30)", "screen" to "Aaj phone zyada chal gaya (shaam 8 baje)"
    )

    private val texts = mapOf(
        "meals" to listOf("Khana ka waqt ho gaya, kuch kha lo 🍽", "Pait pooja ka waqt! Aaram se kha lena 💜", "Thoda ruk ke khana kha lo, kaam baad mein 🍛", "Bhook lagi hogi na? Khana kha lo 😊"),
        "water" to listOf("Ek glass paani ho jaye? 💧", "Paani ka waqt hai, thoda pee lo 💧", "Gala sookha na ho, paani pee lo 🥤", "Chalo, ek ghoont paani 💧"),
        "eyes" to listOf("20 second door dekh lo, aankhon ko aaram 👀", "Aankhon ka break: 20 feet door dekho 20 second 👀", "Screen se nazar hata ke thoda door dekho 🌿", "Aankhein thak gayi hongi, thoda break 💜"),
        "walk" to listOf("Thoda uth ke chal lo? 🚶", "Kursi se uthne ka waqt, zara tehal lo 🚶", "Pair seedhe kar lo, chhoti si walk? 🌤", "Ek minute stretch kar lo 💜"),
        "sleep" to listOf("Sone ka waqt ho raha hai, phone rakh do 🌙", "Der ho rahi hai, aaram kar lo 🌙", "Chalo, ab so jaate hain. Shab bakhair 💜", "Kal phir baat karenge, abhi neend 😴"),
        "screen" to listOf("Aaj phone kaafi chala, thoda break? 📱", "Aaj screen time zyada hai, thoda door rakh lo 📱", "Phone ko thodi chhutti de do 🌿", "Aaj phone zyada chal gaya, kuch aur kar lo 💜")
    )

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isOn(ctx: Context, kind: String) = p(ctx).getBoolean("k_$kind", false)
    fun setKind(ctx: Context, kind: String, on: Boolean) { p(ctx).edit().putBoolean("k_$kind", on).apply() }
    fun master(ctx: Context) = p(ctx).getBoolean("on", false)
    fun setMaster(ctx: Context, on: Boolean) { p(ctx).edit().putBoolean("on", on).apply() }
    fun screenLimitHours(ctx: Context) = p(ctx).getInt("screenLimitH", 4)
    fun setScreenLimitHours(ctx: Context, h: Int) { p(ctx).edit().putInt("screenLimitH", h.coerceIn(1, 12)).apply() }
    fun quietStart(ctx: Context) = p(ctx).getInt("quietStart", 23)
    fun quietEnd(ctx: Context) = p(ctx).getInt("quietEnd", 7)

    private fun today(): String { val c = Calendar.getInstance(); return "${c.get(Calendar.YEAR)}-${c.get(Calendar.DAY_OF_YEAR)}" }
    fun muteToday(ctx: Context) { p(ctx).edit().putString("muteDay", today()).apply() }

    /** Creates / removes the wellness rows to match the switches. */
    fun sync(ctx: Context) {
        ReminderStore.ensure(ctx)
        for (r in ReminderStore.all().filter { it.kind == "wellness" }) ReminderScheduler.cancel(ctx, r.id)
        ReminderStore.deleteKind("wellness")
        if (!master(ctx)) return
        fun at(h: Int, m: Int): Long {
            val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
            return c.timeInMillis
        }
        fun nextEven(minutes: Int): Long = System.currentTimeMillis() + minutes * 60_000L
        val rows = ArrayList<Triple<String, Long, String>>() // text-key, first time, repeat
        if (isOn(ctx, "meals")) { rows.add(Triple("meals", at(8, 30), "daily")); rows.add(Triple("meals", at(13, 30), "daily")); rows.add(Triple("meals", at(20, 30), "daily")) }
        if (isOn(ctx, "water")) rows.add(Triple("water", nextEven(120), "every_120_min"))
        if (isOn(ctx, "eyes")) rows.add(Triple("eyes", nextEven(60), "every_60_min"))
        if (isOn(ctx, "walk")) rows.add(Triple("walk", nextEven(90), "every_90_min"))
        if (isOn(ctx, "sleep")) rows.add(Triple("sleep", at(22, 30), "daily"))
        if (isOn(ctx, "screen")) rows.add(Triple("screen", at(20, 0), "daily"))
        for ((k, t, rep) in rows) {
            val r = ReminderStore.add("wellness:$k", "wellness", t, rep)
            ReminderScheduler.schedule(ctx, r)
        }
    }

    private fun kindOf(r: Reminder) = r.text.removePrefix("wellness:")

    /** Text for a wellness row, or null when the nudge must not be shown now (limits, quiet hours, screen off, below screen-time limit...). */
    fun textIfAllowed(ctx: Context, r: Reminder): String? {
        val k = kindOf(r)
        if (!master(ctx) || !isOn(ctx, k)) return null
        val pr = p(ctx)
        if (pr.getString("muteDay", "") == today()) { ReminderStore.log("nudge skipped ($k): silenced for today"); return null }
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val qs = quietStart(ctx); val qe = quietEnd(ctx)
        val quiet = if (qs > qe) (h >= qs || h < qe) else (h in qs until qe)
        if (quiet) { ReminderStore.log("nudge skipped ($k): quiet hours"); return null }
        if ((k == "water" || k == "walk" || k == "eyes") && h !in 9..21) { ReminderStore.log("nudge skipped ($k): outside daytime"); return null }
        if ((k == "walk" || k == "eyes") && !(ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive) { ReminderStore.log("nudge skipped ($k): screen is off"); return null }
        val dayKey = "count_" + today()
        if (pr.getInt(dayKey, 0) >= 6) { ReminderStore.log("nudge skipped ($k): daily limit"); return null }
        val now = System.currentTimeMillis()
        if (now - pr.getLong("last_$k", 0L) < 2 * 3_600_000L) { ReminderStore.log("nudge skipped ($k): same kind within 2 h"); return null }
        if (k == "screen") {
            val used = screenMinutesToday(ctx)
            if (used < 0 || used < screenLimitHours(ctx) * 60) { ReminderStore.log("nudge skipped (screen): below limit or no usage access"); return null }
        }
        val list = texts[k] ?: return null
        val n = pr.getInt("rot_$k", 0)
        pr.edit().putInt("rot_$k", n + 1).putInt(dayKey, pr.getInt(dayKey, 0) + 1).putLong("last_$k", now).apply()
        return list[n % list.size]
    }

    @Suppress("DEPRECATION")
    fun hasUsageAccess(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    /** Minutes of screen time today (sum of foreground time), or -1 without usage access. */
    private fun screenMinutesToday(ctx: Context): Int {
        if (!hasUsageAccess(ctx)) return -1
        return try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val start = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
            val ms = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, System.currentTimeMillis()).sumOf { it.totalTimeInForeground }
            (ms / 60_000L).toInt()
        } catch (e: Exception) { -1 }
    }
}
