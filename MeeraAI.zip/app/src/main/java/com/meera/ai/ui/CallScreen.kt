package com.meera.ai.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.DisposableEffect
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.avatar.AvatarExpr
import com.meera.ai.avatar.AvatarVideo
import com.meera.ai.avatar.rememberOnline
import com.meera.ai.voice.CallState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight

@Composable
fun CallScreen() {
    val call = Meera.call
    val ctx = LocalContext.current
    val view = LocalView.current
    val state by call.state.collectAsState()
    val status by call.status.collectAsState()
    val subs by call.subtitles.collectAsState()
    val muted by call.muted.collectAsState()
    val speaker by call.speaker.collectAsState()
    val secs by call.seconds.collectAsState()
    val mode by call.modeLabel.collectAsState()
    val callMood by call.callMood.collectAsState()
    val inCall = state != CallState.Idle && state != CallState.Error
    val list = rememberLazyListState()

    // keep the screen awake during a call; the call itself keeps running in the background service
    DisposableEffect(inCall) {
        view.keepScreenOn = inCall
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(subs.size, subs.lastOrNull()?.text) {
        if (subs.isNotEmpty()) list.scrollToItem(subs.size - 1)
    }

    // Bluetooth permission (Android 12+) is asked once, only when a Bluetooth audio device is connected; "no" = phone speaker.
    val btPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> call.start() }
    fun afterMic() {
        val flags = ctx.getSharedPreferences("meera_flags", Context.MODE_PRIVATE)
        val needBt = Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED &&
            !flags.getBoolean("btAsked", false) && call.route.btDeviceConnected()
        if (needBt) {
            flags.edit().putBoolean("btAsked", true).apply()
            btPerm.launch(Manifest.permission.BLUETOOTH_CONNECT)
        } else call.start()
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) afterMic() else {
            call.status.value = "Microphone permission denied. Allow it in Permissions screen."
        }
    }
    fun startCall() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) afterMic()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }
    val audioLabel by call.route.label.collectAsState()
    val routeNote by call.route.note.collectAsState()
    var audioMenu by remember { mutableStateOf(false) }

    // Avatar: she stands there blinking while she listens, her mouth/expression follow the voice that is really
    // playing, and with no internet / a broken call she goes quiet and sad. Every change is a morph cross-fade.
    val online by rememberOnline()
    val clip = AvatarExpr.forCall(state, callMood, online)

    Box(Modifier.fillMaxSize()) {
        AvatarVideo(clip, Modifier.fillMaxSize(), focusY = 0.3f)
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0f to Color(0xB3050914), 0.2f to Color(0x1A050914), 0.5f to Color(0x00050914), 1f to Color(0xF2050914))
            )
        )
        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Meera Call", fontSize = 20.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(
                if (inCall) "%02d:%02d  •  %s".format(secs / 60, secs % 60, mode) else "AI voice call - Meera is an AI, not a human",
                color = Color(0xFFD5DDF5), fontSize = 13.sp
            )
            Spacer(Modifier.weight(1f)) // the avatar shows through here
            Text(
                when {
                    !online && inCall -> "● No internet"
                    state == CallState.Idle -> "Ready"
                    state == CallState.Connecting -> "Connecting"
                    state == CallState.Listening -> "● Listening"
                    state == CallState.Thinking -> "● Thinking"
                    state == CallState.Speaking -> "● Speaking"
                    else -> "Problem"
                },
                fontSize = 18.sp, color = Color.White, fontWeight = FontWeight.Medium
            )
            Text(
                status, fontSize = 13.sp,
                color = if (state == CallState.Error) MaterialTheme.colorScheme.error else Color(0xFFD5DDF5)
            )
            if (inCall) {
                Text("Audio: $audioLabel", fontSize = 12.sp, color = Color(0xFFB9C3E0))
                if (routeNote.isNotBlank()) Text(routeNote, fontSize = 12.sp, color = Pink)
            }
            LazyColumn(
                Modifier.fillMaxWidth().height(if (subs.isEmpty()) 8.dp else 150.dp).padding(vertical = 6.dp)
                    .glass(RoundedCornerShape(20.dp), if (subs.isEmpty()) 0f else 1f).padding(horizontal = 12.dp, vertical = 6.dp),
                state = list, verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(subs) { s ->
                    Text(
                        "${s.who}: ${s.text}",
                        color = if (s.who == "You") Cyan else Pink, fontSize = 15.sp
                    )
                }
            }
            if (inCall) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PremiumOutlinedButton(onClick = { call.toggleMute() }, modifier = Modifier.weight(1f).height(52.dp)) {
                        Text(if (muted) "🔇 Unmute" else "🎙 Mute", fontSize = 13.sp)
                    }
                    PremiumOutlinedButton(onClick = { call.interrupt() }, modifier = Modifier.weight(1f).height(52.dp)) {
                        Text("✋ Interrupt", fontSize = 13.sp)
                    }
                    Box(Modifier.weight(1f)) {
                        PremiumOutlinedButton(onClick = { audioMenu = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                            Text("🔊 " + audioLabel.removePrefix("Bluetooth: ").let { if (audioLabel.startsWith("Bluetooth")) "BT: $it" else it }, fontSize = 12.sp, maxLines = 1)
                        }
                        DropdownMenu(expanded = audioMenu, onDismissRequest = { audioMenu = false }) {
                            call.route.options().forEach { (key, text) ->
                                DropdownMenuItem(text = { Text(text) }, onClick = { call.route.select(key); audioMenu = false })
                            }
                        }
                    }
                }
                PremiumButton(
                    onClick = { call.stop() },
                    gradient = listOf(Color(0xFFFF5F6D), Color(0xFFE5484D)),
                    modifier = Modifier.fillMaxWidth().height(56.dp).padding(top = 8.dp)
                ) { Text("End call", fontSize = 17.sp, color = Color.White) }
            } else {
                PremiumButton(
                    onClick = { startCall() },
                    gradient = listOf(Color(0xFF00C6FF), Color(0xFF7C4DFF)),
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) { Text("📞  Start call", fontSize = 17.sp) }
                Text(
                    "Tip: barge-in (talking while Meera speaks) works best with headphones.",
                    fontSize = 12.sp, color = Color(0xFFB9C3E0), modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}
