package com.meera.ai.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/* ---------------------------------------------------------------------------------------------------------
 * Glassmorphism kit: soft coloured light behind frosted, translucent panels with a bright edge.
 * (Compose cannot blur what is behind a panel, so the "frost" is a translucent white gradient + glowing
 * border over a backdrop of colourful light - same look, no performance cost.)
 * ------------------------------------------------------------------------------------------------------- */

/** Backdrop for every screen: deep gradient with three soft colour orbs. */
@Composable
fun Modifier.glassBackdrop(): Modifier {
    val dark = LocalDark.current
    return this.drawBehind {
        val w = size.width
        val h = size.height
        if (dark) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF050914), Color(0xFF0A1226), Color(0xFF0D0A22))))
        } else {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFEAF2FF), Color(0xFFF3ECFF), Color(0xFFFFEFF7))))
        }
        val k = if (dark) 1f else 0.55f
        fun orb(c: Color, cx: Float, cy: Float, r: Float) {
            val o = Offset(cx, cy)
            drawCircle(Brush.radialGradient(listOf(c.copy(alpha = 0.30f * k), Color.Transparent), center = o, radius = r), radius = r, center = o)
        }
        orb(Cyan, w * 0.08f, h * 0.10f, w * 0.85f)
        orb(Purple, w * 0.98f, h * 0.48f, w * 0.80f)
        orb(Pink, w * 0.15f, h * 0.96f, w * 0.85f)
    }
}

/** Frosted-glass surface: clip + translucent gradient + bright gradient edge. */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(22.dp), strength: Float = 1f): Modifier {
    val dark = LocalDark.current
    val top = if (dark) 0.16f else 0.70f
    val bottom = if (dark) 0.05f else 0.42f
    val edgeA = if (dark) 0.55f else 0.95f
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = top * strength), Color.White.copy(alpha = bottom * strength))))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = edgeA), Color.White.copy(alpha = 0.06f), Cyan.copy(alpha = 0.40f))), shape)
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    val m = if (onClick != null) modifier.glass(shape).clickable { onClick() } else modifier.glass(shape)
    Column(m.padding(14.dp), content = content)
}

private val BrandGrad = listOf(Color(0xFF1E90FF), Color(0xFF7C4DFF))

/**
 * Premium filled button: gradient, glossy edge, soft glow, press-scale. Drop-in for material3 Button.
 * If [colors] is given the button keeps those colours (still with the new shape/press effect);
 * [gradient] lets a screen choose its own two-colour gradient (e.g. red for "End call").
 */
@Composable
fun PremiumButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors? = null,
    gradient: List<Color> = BrandGrad,
    shape: Shape = RoundedCornerShape(16.dp),
    content: @Composable RowScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.96f else 1f, tween(110), label = "pbScale")
    val base = modifier.graphicsLayer { scaleX = sc; scaleY = sc; alpha = if (enabled) 1f else 0.45f }
    if (colors != null) {
        Button(onClick = onClick, modifier = base, enabled = enabled, shape = shape, colors = colors, interactionSource = src, content = content)
    } else {
        val glow = gradient.first()
        val m = (if (enabled) base.shadow(10.dp, shape, clip = false, ambientColor = glow, spotColor = glow) else base)
            .clip(shape)
            .background(Brush.horizontalGradient(gradient))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.60f), Color.White.copy(alpha = 0.08f))), shape)
        Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Transparent, contentColor = Color.White,
                disabledContainerColor = Color.Transparent, disabledContentColor = Color.White
            ),
            elevation = null, interactionSource = src, content = content
        )
    }
}

/** Premium glass button (translucent fill, glowing gradient border). Drop-in for material3 OutlinedButton. */
@Composable
fun PremiumOutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors? = null,
    shape: Shape = RoundedCornerShape(16.dp),
    content: @Composable RowScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.96f else 1f, tween(110), label = "pobScale")
    val dark = LocalDark.current
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.graphicsLayer { scaleX = sc; scaleY = sc },
        enabled = enabled,
        shape = shape,
        colors = colors ?: ButtonDefaults.outlinedButtonColors(
            containerColor = if (dark) Color(0x1AFFFFFF) else Color(0x99FFFFFF),
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        border = BorderStroke(1.2.dp, Brush.linearGradient(listOf(Cyan.copy(alpha = 0.85f), Purple.copy(alpha = 0.65f)))),
        interactionSource = src,
        content = content
    )
}

/** Round glass icon holder used by the Home dock and menu button. */
fun Modifier.glassCircle(size: Dp, ring: Color = Cyan): Modifier =
    this
        .shadow(8.dp, androidx.compose.foundation.shape.CircleShape, clip = false, ambientColor = ring, spotColor = ring)
        .clip(androidx.compose.foundation.shape.CircleShape)
        .background(Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x14FFFFFF))))
        .border(1.5.dp, Brush.linearGradient(listOf(ring, Color.White.copy(alpha = 0.25f), ring.copy(alpha = 0.6f))), androidx.compose.foundation.shape.CircleShape)
