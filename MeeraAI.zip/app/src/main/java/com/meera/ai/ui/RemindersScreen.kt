package com.meera.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.reminders.Reminder
import com.meera.ai.reminders.ReminderNotifier
import com.meera.ai.reminders.ReminderScheduler
import com.meera.ai.reminders.ReminderStore
import com.meera.ai.reminders.Wellness
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemindersScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val items by ReminderStore.items.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    LaunchedEffect(Unit) { ReminderStore.ensure(ctx) }
    tick.let { }

    val notif = ReminderNotifier.notificationsAllowed(ctx)
    val exact = ReminderScheduler.canExact(ctx)
    val battery = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    val usage = Wellness.hasUsageAccess(ctx)
    var master by remember { mutableStateOf(Wellness.master(ctx)) }
    var limit by remember { mutableIntStateOf(Wellness.screenLimitHours(ctx)) }
    val flags = remember { mutableStateOf(Wellness.kinds.associateWith { Wellness.isOn(ctx, it) }) }
    val fmt = remember { SimpleDateFormat("EEE d MMM, HH:mm", Locale.ENGLISH) }
    val logFmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH) }

    fun open(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } }

    SubScreen("Reminders", onBack) {
        Text(
            "Meera's own reminders (notification with Ho gaya / 10 min baad / Band karo). Ask her in chat or call: \"kal subah 8 baje yaad dila dena\". " +
                "The phone's Clock alarms are separate and work as before.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionTitle("Check list")
        @Composable
        fun check(title: String, ok: Boolean, label: String, onClick: () -> Unit) {
            GlowCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (ok) "✅" else "❌")
                    Text(title, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                    if (!ok) PremiumOutlinedButton(onClick = onClick) { Text(label) }
                }
            }
        }
        check("Notification permission", notif, "Allow") {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            else open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
        }
        check("Exact alarms (on time, not late)", exact, "Allow") {
            if (Build.VERSION.SDK_INT >= 31) open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
        }
        check("Battery optimisation off (more reliable)", battery, "Open") { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        check("Usage access (only for the screen-time nudge)", usage, "Open") { open(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PremiumOutlinedButton(onClick = {
                ReminderNotifier.show(ctx, Reminder(0L, "test", "reminder", 0L, "none", true, 0L, 0L, 0L), test = true)
            }) { Text("Test notification") }
            PremiumOutlinedButton(onClick = {
                val r = ReminderStore.add("Test reminder ⏰ (2 minute)", "reminder", System.currentTimeMillis() + 120_000L, "none")
                ReminderScheduler.schedule(ctx, r)
            }) { Text("Remind in 2 min") }
        }

        SectionTitle("Meera ki yaad-dahaniyan (nudges)")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(master, { master = it; Wellness.setMaster(ctx, it); Wellness.sync(ctx) })
            Text("  Gentle nudges (OFF by default)")
        }
        Text(
            "Quiet hours 11 pm - 7 am, at most 6 a day, one kind per 2 hours, \"Aaj chup\" silences the rest of the day. Friendly nudges only - no medical advice.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (master) {
            Wellness.kinds.forEach { k ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(flags.value[k] == true, { on ->
                        Wellness.setKind(ctx, k, on)
                        flags.value = flags.value + (k to on)
                        Wellness.sync(ctx)
                    })
                    Text("  " + (Wellness.labels[k] ?: k), fontSize = 14.sp)
                }
            }
            Text("Screen-time limit for the evening nudge:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(2, 3, 4, 6).forEach { h ->
                    FilterChip(selected = limit == h, onClick = { limit = h; Wellness.setScreenLimitHours(ctx, h) }, label = { Text("$h h") })
                }
            }
        }

        SectionTitle("My reminders")
        val mine = items.filter { it.kind == "reminder" }
        if (mine.isEmpty()) Text("No reminders yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        mine.forEach { r ->
            GlowCard(Modifier.fillMaxWidth()) {
                Text(r.text, color = MaterialTheme.colorScheme.onSurface)
                Text(
                    fmt.format(Date(r.triggerAt)) + (if (r.repeat != "none") "  •  repeat ${r.repeat}" else ""),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Switch(r.enabled, { on ->
                        val n = r.copy(enabled = on)
                        ReminderStore.save(n)
                        ReminderScheduler.schedule(ctx, n)
                    })
                    Text(if (r.enabled) "On" else "Off", modifier = Modifier.weight(1f))
                    PremiumOutlinedButton(onClick = { ReminderScheduler.cancel(ctx, r.id); ReminderStore.delete(r.id) }) { Text("Delete") }
                }
            }
        }

        SectionTitle("Log (fired / missed / skipped)")
        val lines = remember(items, tick) { ReminderStore.logLines() }
        if (lines.isEmpty()) Text("Nothing logged yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        lines.forEach { (ts, line) -> Text(logFmt.format(Date(ts)) + "  " + line, fontSize = 12.sp, modifier = Modifier.padding(vertical = 1.dp)) }
        if (lines.isNotEmpty()) PremiumOutlinedButton(onClick = { ReminderStore.clearLog(); tick++ }) { Text("Clear log") }
    }
}
