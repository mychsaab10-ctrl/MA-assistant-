package com.meera.ai.voice

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * Where the call audio goes: Auto (Bluetooth headset > wired/USB headset > phone speaker/earpiece), or a manual choice.
 * ONLY the routing is handled here (setCommunicationDevice on Android 12+, Bluetooth SCO on Android 8-11).
 * AudioCapture / AudioPlayer are not touched, the mic and the Live session are never restarted when the route changes.
 */
class AudioRoute(private val ctx: Context, private val scope: CoroutineScope) {

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val main = Handler(Looper.getMainLooper())

    /** auto | speaker | earpiece | bt | wired */
    val choice = MutableStateFlow("auto")
    /** e.g. "Bluetooth: Buds Pro", "Speaker", "Earpiece", "Headset" */
    val label = MutableStateFlow("Speaker")
    /** why the route fell back (empty when everything is fine) */
    val note = MutableStateFlow("")

    private var active = false
    private var inComm = false
    private var speakerPref = true
    private var reapplyJob: Job? = null
    private var scoJob: Job? = null
    private var scoReceiver: BroadcastReceiver? = null
    private var devCallback: AudioDeviceCallback? = null
    private var commListener: Any? = null // AudioManager.OnCommunicationDeviceChangedListener (API 31+)

    // ---------- what is connected ----------

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun isBt(t: Int) =
        t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || (Build.VERSION.SDK_INT >= 31 && t == AudioDeviceInfo.TYPE_BLE_HEADSET) ||
            (Build.VERSION.SDK_INT >= 28 && t == AudioDeviceInfo.TYPE_HEARING_AID)

    private fun isWired(t: Int) =
        t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == AudioDeviceInfo.TYPE_USB_HEADSET

    private fun outputs(): List<AudioDeviceInfo> =
        if (Build.VERSION.SDK_INT >= 31) audio.availableCommunicationDevices
        else audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()

    /** A Bluetooth audio device is paired and connected (any profile) - used to decide whether to ask for the permission. */
    fun btDeviceConnected(): Boolean = try {
        audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { isBt(it.type) || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
    } catch (e: Exception) { false }

    fun btAvailable(): Boolean = try {
        hasBtPermission() && outputs().any { isBt(it.type) || (Build.VERSION.SDK_INT < 31 && it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) }
    } catch (e: Exception) { false }

    private fun wiredAvailable(): Boolean = try { outputs().any { isWired(it.type) } } catch (e: Exception) { false }

    private fun describe(d: AudioDeviceInfo): String = when {
        isBt(d.type) -> "Bluetooth: " + (d.productName?.toString()?.takeIf { it.isNotBlank() } ?: "headset")
        isWired(d.type) -> "Headset"
        d.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Speaker"
        d.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "Earpiece"
        else -> d.productName?.toString() ?: "Audio"
    }

    /** Entries for the Audio menu: (key, text). */
    fun options(): List<Pair<String, String>> {
        val l = ArrayList<Pair<String, String>>()
        l.add("auto" to "Auto (best available)")
        l.add("speaker" to "Speaker")
        l.add("earpiece" to "Earpiece")
        try {
            outputs().firstOrNull { isBt(it.type) }?.let { if (hasBtPermission()) l.add("bt" to describe(it)) }
            outputs().firstOrNull { isWired(it.type) }?.let { l.add("wired" to "Headset") }
        } catch (e: Exception) { }
        return l
    }

    fun select(key: String) {
        choice.value = key
        reapply()
    }

    // ---------- apply / restore ----------

    private fun resolve(): String {
        val c = choice.value
        return when (c) {
            "bt" -> if (btAvailable()) "bt" else fallbackBuiltIn("Bluetooth device is not available")
            "wired" -> if (wiredAvailable()) "wired" else fallbackBuiltIn("Headset is not connected")
            "speaker", "earpiece" -> c
            else -> when { // auto
                btAvailable() -> "bt"
                wiredAvailable() -> "wired"
                speakerPref -> "speaker"
                else -> "earpiece"
            }
        }
    }

    private fun fallbackBuiltIn(why: String): String {
        note.value = "$why - using the phone ${if (speakerPref) "speaker" else "earpiece"}."
        return if (speakerPref) "speaker" else "earpiece"
    }

    @Suppress("DEPRECATION")
    fun apply(inCommunication: Boolean, speakerFirst: Boolean) {
        inComm = inCommunication
        speakerPref = speakerFirst
        active = true
        note.value = ""
        if (inCommunication) audio.mode = AudioManager.MODE_IN_COMMUNICATION // unchanged: the call keeps this mode
        registerCallbacks()
        if (Build.VERSION.SDK_INT >= 31 && !hasBtPermission() && btDeviceConnected() && choice.value == "auto") {
            note.value = "Bluetooth permission is off - using the phone speaker. Allow it in Permissions to use your earbuds."
        }
        val want = resolve()
        if (Build.VERSION.SDK_INT >= 31) applyModern(want) else applyLegacy(want)
        updateLabel()
    }

    private fun reapply() {
        if (active) apply(inComm, speakerPref)
    }

    /** Android 12+: choose the communication device, then check that Android really switched. */
    private fun applyModern(want: String) {
        val devs = audio.availableCommunicationDevices
        val dev = when (want) {
            "bt" -> devs.firstOrNull { isBt(it.type) }
            "wired" -> devs.firstOrNull { isWired(it.type) }
            "speaker" -> devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            else -> devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE }
        }
        if (dev == null) {
            audio.clearCommunicationDevice()
            return
        }
        val requested = audio.setCommunicationDevice(dev)
        scope.launch {
            delay(450) // the new route needs a moment before the audio is really there
            val now = audio.communicationDevice
            if (!requested || now == null || now.id != dev.id) {
                if (want == "bt" || want == "wired") {
                    note.value = "Could not switch to ${describe(dev)} - using the phone speaker."
                    audio.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                        ?.let { audio.setCommunicationDevice(it) }
                }
            }
            updateLabel()
        }
    }

    /** Android 8-11: Bluetooth SCO (wait up to 4 s for CONNECTED) or speakerphone on/off. */
    @Suppress("DEPRECATION")
    private fun applyLegacy(want: String) {
        scoJob?.cancel()
        if (want == "bt") {
            startSco()
            return
        }
        stopSco()
        audio.isSpeakerphoneOn = want == "speaker"
    }

    @Suppress("DEPRECATION")
    private fun startSco() {
        if (audio.isBluetoothScoOn) return
        unregisterSco()
        val rcv = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                val st = i?.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1) ?: return
                if (st == AudioManager.SCO_AUDIO_STATE_CONNECTED) {
                    scoJob?.cancel()
                    updateLabel()
                }
            }
        }
        scoReceiver = rcv
        ContextCompat.registerReceiver(
            ctx, rcv, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        audio.isSpeakerphoneOn = false
        audio.startBluetoothSco()
        audio.isBluetoothScoOn = true
        scoJob = scope.launch {
            delay(4000)
            note.value = "Bluetooth did not connect within 4 s - using the phone speaker."
            stopSco()
            audio.isSpeakerphoneOn = true
            updateLabel()
        }
    }

    @Suppress("DEPRECATION")
    private fun stopSco() {
        try {
            if (audio.isBluetoothScoOn) {
                audio.isBluetoothScoOn = false
                audio.stopBluetoothSco()
            }
        } catch (e: Exception) { }
        unregisterSco()
    }

    private fun unregisterSco() {
        scoReceiver?.let { try { ctx.unregisterReceiver(it) } catch (e: Exception) { } }
        scoReceiver = null
    }

    // ---------- live changes (earbuds put in / taken out in the middle of a call) ----------

    private fun registerCallbacks() {
        if (devCallback == null) {
            val cb = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) = changed()
                override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) = changed()
            }
            devCallback = cb
            audio.registerAudioDeviceCallback(cb, main)
        }
        if (Build.VERSION.SDK_INT >= 31 && commListener == null) {
            val l = AudioManager.OnCommunicationDeviceChangedListener { updateLabel() }
            commListener = l
            audio.addOnCommunicationDeviceChangedListener(ContextCompat.getMainExecutor(ctx), l)
        }
    }

    private fun changed() {
        if (!active) return
        reapplyJob?.cancel()
        reapplyJob = scope.launch {
            delay(400) // let Android finish connecting / disconnecting first
            if (active && choice.value != "speaker" && choice.value != "earpiece") reapply() else updateLabel()
        }
    }

    @Suppress("DEPRECATION")
    private fun updateLabel() {
        label.value = try {
            if (Build.VERSION.SDK_INT >= 31) {
                audio.communicationDevice?.let { describe(it) } ?: (if (speakerPref) "Speaker" else "Earpiece")
            } else when {
                audio.isBluetoothScoOn -> "Bluetooth"
                audio.isSpeakerphoneOn -> "Speaker"
                wiredAvailable() -> "Headset"
                else -> "Earpiece"
            }
        } catch (e: Exception) { "Speaker" }
    }

    /** End of the call: communication device cleared, SCO stopped, mode normal, callbacks removed. */
    @Suppress("DEPRECATION")
    fun restore() {
        active = false
        reapplyJob?.cancel(); reapplyJob = null
        scoJob?.cancel(); scoJob = null
        try {
            if (Build.VERSION.SDK_INT >= 31) audio.clearCommunicationDevice()
            else {
                stopSco()
                audio.isSpeakerphoneOn = false
            }
            audio.mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) { }
        unregisterSco()
        devCallback?.let { try { audio.unregisterAudioDeviceCallback(it) } catch (e: Exception) { } }
        devCallback = null
        if (Build.VERSION.SDK_INT >= 31) {
            (commListener as? AudioManager.OnCommunicationDeviceChangedListener)?.let {
                try { audio.removeOnCommunicationDeviceChangedListener(it) } catch (e: Exception) { }
            }
        }
        commListener = null
        note.value = ""
    }
}
