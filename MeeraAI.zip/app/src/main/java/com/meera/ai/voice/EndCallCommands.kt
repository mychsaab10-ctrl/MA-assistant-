package com.meera.ai.voice

/**
 * Local matcher for "end the call" - works on the USER'S OWN words (the transcription), never on Gemini's.
 * Roman Urdu / English / Devanagari / Urdu script. Negations ("call cut mat karo"), past or question forms
 * ("call kat gayi thi", "call kab khatam hogi") and talk about someone else's call do not match.
 *
 * phoneCall = true is used for the hangup_phone_call tool ("meri call kaat do"): the same words, but talk about
 * "my / the other / WhatsApp call" is allowed because the target is then the phone call, not Meera's call.
 */
object EndCallCommands {
    private val negation = setOf(
        "mat", "nahi", "nahin", "nhi", "nhin", "dont", "don't", "not", "never",
        "मत", "नहीं", "नही", "مت", "نہیں"
    )
    private val skip = setOf(
        "thi", "tha", "gayi", "gaya", "hui", "hua", "kal", "yesterday", "was", "were", "when", "jab", "agar", "if",
        "kyun", "kyon", "why", "kaise", "how", "kab", "kitni", "kitna", "kitne"
    )
    private val otherCall = setOf("meri", "mera", "mere", "my", "incoming", "whatsapp", "doosri", "dusri", "doosre", "dusre", "uski", "unki", "iski")
    private val callWords = setOf("call", "calls", "phone", "fone", "कॉल", "काल", "फोन", "फ़ोन", "کال", "فون")
    private val endWords = setOf(
        "end", "cut", "kat", "kaat", "kato", "katt", "kaato", "band", "khatam", "khatm", "rakh", "rakho", "rakhdo", "hang", "hangup", "disconnect",
        "कट", "काट", "बंद", "बन्द", "खत्म", "ख़त्म", "रख", "रखो", "کاٹ", "بند", "ختم", "رکھ", "رکھو"
    )
    private val farewell = setOf(
        "bye", "byee", "byebye", "goodbye", "alvida", "hafiz", "hafez", "hafeez",
        "बाय", "अलविदा", "हाफ़िज़", "हाफिज", "الوداع", "حافظ"
    )

    private val punct = Regex("[^\\p{L}\\p{M}\\p{N}' ]")
    private val spaces = Regex("\\s+")

    fun match(text: String, phoneCall: Boolean = false): Boolean {
        val t = text.lowercase().replace('’', '\'').replace(punct, " ").replace(spaces, " ").trim()
        if (t.isEmpty()) return false
        val w = t.split(' ')
        if (w.size > 8) return false
        if (w.any { it in negation }) return false
        if (w.any { it in skip }) return false
        if (!phoneCall && w.any { it in otherCall }) return false
        if (t.contains("hang up") || t.contains("hangup")) return true
        if (w.any { it in callWords } && w.any { it in endWords }) return true
        // a short goodbye counts only when the whole sentence is shorter than 4 words
        if (!phoneCall && w.size < 4 && w.any { it in farewell }) return true
        return false
    }
}
